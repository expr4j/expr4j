package com.pramanda.expr;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OrderedHashMap<K, V> extends HashMap<K, V> {
	
	private static final long serialVersionUID = -7498720665436078832L;
	
	private List<K> keys;
	
	{
		this.keys = new ArrayList<>();
	}

	public OrderedHashMap() {
		super();
	}

	public OrderedHashMap(int initialCapacity, float loadFactor) {
		super(initialCapacity, loadFactor);
	}

	public OrderedHashMap(int initialCapacity) {
		super(initialCapacity);
	}

	public OrderedHashMap(Map<? extends K, ? extends V> m) {
		super(m);
	}
	
	@Override
	public V put(K key, V value) {
		if (!this.keys.contains(key)) {
			this.keys.add(key);
		}
		return super.put(key, value);
	}
	
	@Override
	public V remove(Object key) {
		this.keys.remove(key);
		return super.remove(key);
	}
	
	public K getKey(int index) {
		return this.keys.get(index);
	}
	
	public V get(int index) {
		return this.get(keys.get(index));
	}
	
	public int getIndex(K key) {
		return this.keys.indexOf(key);
	}

}
